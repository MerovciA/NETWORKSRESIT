// IN2011 Computer Networks
// Coursework 2023/2024 Resit
//
// Submission by
// YOUR_NAME_GOES_HERE
// YOUR_STUDENT_ID_NUMBER_GOES_HERE
// YOUR_EMAIL_GOES_HERE

import java.net.InetAddress;
import java.net.*;
import java.util.concurrent.*;
import java.net.*;
import java.util.concurrent.*;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

// DO NOT EDIT starts
interface NameServerInterface {
    public void setNameServer(InetAddress ipAddress, int port);
    public void handleIncomingQueries(int port) throws Exception;
}
// DO NOT EDIT ends



public class NameServer implements NameServerInterface {

    private InetAddress dnsServerAddress;
    private int dnsServerPort;
    private final Map<String, CachedDNSRecord> cache;

    // Cache entry class
    private class CachedDNSRecord {
        public byte[] responseData;
        public long expiryTime;

        public CachedDNSRecord(byte[] responseData, long expiryTime) {
            this.responseData = responseData;
            this.expiryTime = expiryTime;
        }
    }

    public NameServer() {
        cache = new HashMap<>();
    }

    @Override
    public void setNameServer(InetAddress ipAddress, int port) {
        this.dnsServerAddress = ipAddress;
        this.dnsServerPort = port;
    }

    @Override
    public void handleIncomingQueries(int port) throws Exception {
        DatagramSocket socket = new DatagramSocket(port);

        while (true) {
            try {
                // Receive the incoming packet
                byte[] buffer = new byte[512];
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet);

                // Handle the DNS query
                new Thread(() -> handleDNSQuery(packet, socket)).start();

            } catch (Exception e) {
                System.err.println("Error handling incoming query: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void handleDNSQuery(DatagramPacket packet, DatagramSocket socket) {
        try {
            String queryName = extractQueryName(packet.getData());

            // Check cache
            byte[] response = checkCache(queryName);
            if (response == null) {
                // Perform iterative resolution if not in cache
                response = performIterativeResolution(packet.getData());
                // Cache the result
                cacheDNSResponse(queryName, response);
            }

            // Send the response back to the client
            DatagramPacket responsePacket = new DatagramPacket(response, response.length, packet.getAddress(), packet.getPort());
            socket.send(responsePacket);

        } catch (Exception e) {
            System.err.println("Error processing DNS query: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String extractQueryName(byte[] requestData) {
        // Extract and return the domain name from the DNS query
        // This is a simplified implementation; you may need to parse the DNS request properly
        return "example.com"; // Placeholder implementation
    }

    private byte[] checkCache(String queryName) {
        CachedDNSRecord record = cache.get(queryName);
        if (record != null && record.expiryTime > System.currentTimeMillis()) {
            return record.responseData;
        }
        return null;
    }

    private void cacheDNSResponse(String queryName, byte[] responseData) {
        long ttl = 60 * 1000; // Set TTL to 1 minute for simplicity; extract actual TTL from response
        long expiryTime = System.currentTimeMillis() + ttl;
        cache.put(queryName, new CachedDNSRecord(responseData, expiryTime));
    }

    private byte[] performIterativeResolution(byte[] requestData) throws UnknownHostException {
        // Perform iterative resolution starting with the root DNS server
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket();

            InetAddress currentServer = dnsServerAddress;
            byte[] response = null;

            for (int i = 0; i < 5; i++) { // Limit the number of iterations to avoid infinite loops
                DatagramPacket queryPacket = new DatagramPacket(requestData, requestData.length, currentServer, dnsServerPort);
                socket.send(queryPacket);

                byte[] buffer = new byte[512];
                DatagramPacket responsePacket = new DatagramPacket(buffer, buffer.length);
                socket.receive(responsePacket);

                response = responsePacket.getData();

                // Check if this is a complete response (check flags, response code, etc.)
                if (isCompleteResponse(response)) {
                    return response;
                }

                // Otherwise, extract the next server's address from the response and continue the loop
                currentServer = extractNextServer(response);
            }

            // Return the last received response, even if incomplete, to avoid hanging
            return response;

        } catch (Exception e) {
            System.err.println("Error performing iterative resolution: " + e.getMessage());
            e.printStackTrace();
            return null;
        } finally {
            if (socket != null) {
                socket.close();
            }
        }
    }

    private boolean isCompleteResponse(byte[] response) {
        // Analyze the DNS response to determine if it is a complete answer
        // This would involve checking the flags and response code in the DNS header
        return true; // Placeholder implementation
    }

    private InetAddress extractNextServer(byte[] response) throws UnknownHostException {
        // Extract the IP address of the next server from the response
        // This involves parsing the DNS response to find the appropriate NS or A record
        return InetAddress.getByName("8.8.8.8"); // Placeholder implementation
    }
}

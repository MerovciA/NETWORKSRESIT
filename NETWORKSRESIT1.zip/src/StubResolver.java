// IN2011 Computer Networks
// Coursework 2023/2024 Resit
//
// Submission by
// YOUR_NAME_GOES_HERE
// YOUR_STUDENT_ID_NUMBER_GOES_HERE
// YOUR_EMAIL_GOES_HERE
/*import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

public class StubResolver {

    private InetAddress dnsServer;
    private int port;
    private DatagramSocket socket;

    public StubResolver() throws Exception {
        this.socket = new DatagramSocket();
    }

    public void setNameServer(InetAddress dnsServer, int port) {
        this.dnsServer = dnsServer;
        this.port = port;
    }

    public InetAddress recursiveResolveAddress(String domain) throws Exception {
        byte[] response = sendQuery(domain, 1); // A record type
        return parseAddressResponse(response);
    }

    public String recursiveResolveText(String domain) throws Exception {
        byte[] response = sendQuery(domain, 16); // TXT record type
        return parseTextResponse(response);
    }

    public String recursiveResolveName(String domain, int queryType) throws Exception {
        byte[] response = sendQuery(domain, queryType); // CNAME record type
        return parseCNAMEResponse(response);
    }

    private byte[] sendQuery(String domain, int queryType) throws Exception {
        byte[] query = buildQuery(domain, queryType);
        DatagramPacket packet = new DatagramPacket(query, query.length, dnsServer, port);
        socket.send(packet);

        byte[] responseBuffer = new byte[512];
        DatagramPacket responsePacket = new DatagramPacket(responseBuffer, responseBuffer.length);
        socket.receive(responsePacket);

        return responsePacket.getData();
    }

    private byte[] buildQuery(String domain, int queryType) throws Exception {
        ByteBuffer buffer = ByteBuffer.allocate(512);

        // Transaction ID
        buffer.putShort((short) 0x1234);
        // Flags
        buffer.putShort((short) 0x0100);
        // Questions
        buffer.putShort((short) 1);
        // Answer RRs
        buffer.putShort((short) 0);
        // Authority RRs
        buffer.putShort((short) 0);
        // Additional RRs
        buffer.putShort((short) 0);

        String[] labels = domain.split("\\.");
        for (String label : labels) {
            buffer.put((byte) label.length());
            buffer.put(label.getBytes(StandardCharsets.UTF_8));
        }
        buffer.put((byte) 0); // End of domain name

        buffer.putShort((short) queryType); // Query Type
        buffer.putShort((short) 1); // Class IN

        byte[] query = new byte[buffer.position()];
        buffer.flip();
        buffer.get(query);

        return query;
    }

    private InetAddress parseAddressResponse(byte[] response) throws Exception {
        ByteBuffer buffer = ByteBuffer.wrap(response);

        buffer.getShort(); // Transaction ID
        buffer.getShort(); // Flags
        buffer.getShort(); // Questions
        short answerCount = buffer.getShort(); // Answer RRs
        buffer.getShort(); // Authority RRs
        buffer.getShort(); // Additional RRs

        // Skip the query section
        skipName(buffer);
        buffer.getShort(); // Query Type
        buffer.getShort(); // Query Class

        if (answerCount > 0) {
            // Parse answer section
            skipName(buffer);
            short type = buffer.getShort();
            buffer.getShort(); // Class
            buffer.getInt(); // TTL
            short dataLength = buffer.getShort(); // Data length

            if (type == 1 && dataLength == 4) { // A Record
                byte[] data = new byte[dataLength];
                buffer.get(data);
                return InetAddress.getByAddress(data);
            }
        }

        return null;
    }

    private String parseTextResponse(byte[] response) throws Exception {
        ByteBuffer buffer = ByteBuffer.wrap(response);

        buffer.getShort(); // Transaction ID
        buffer.getShort(); // Flags
        buffer.getShort(); // Questions
        short answerCount = buffer.getShort(); // Answer RRs
        buffer.getShort(); // Authority RRs
        buffer.getShort(); // Additional RRs

        // Skip the query section
        skipName(buffer);
        buffer.getShort(); // Query Type
        buffer.getShort(); // Query Class

        if (answerCount > 0) {
            // Parse answer section
            skipName(buffer);
            short type = buffer.getShort();
            buffer.getShort(); // Class
            buffer.getInt(); // TTL
            short dataLength = buffer.getShort(); // Data length

            if (type == 16) { // TXT Record
                int txtLength = buffer.get() & 0xFF;
                byte[] data = new byte[txtLength];
                buffer.get(data);
                return new String(data, StandardCharsets.UTF_8);
            }
        }

        return null;
    }

    private String parseCNAMEResponse(byte[] response) throws Exception {
        ByteBuffer buffer = ByteBuffer.wrap(response);

        buffer.getShort(); // Transaction ID
        buffer.getShort(); // Flags
        buffer.getShort(); // Questions
        short answerCount = buffer.getShort(); // Answer RRs
        buffer.getShort(); // Authority RRs
        buffer.getShort(); // Additional RRs

        // Skip the query section
        skipName(buffer);
        buffer.getShort(); // Query Type
        buffer.getShort(); // Query Class

        if (answerCount > 0) {
            // Parse answer section
            return parseName(buffer);
        }

        return null;
    }

    private void skipName(ByteBuffer buffer) {
        while (true) {
            int length = buffer.get() & 0xFF;
            if (length == 0) break;
            if ((length & 0xC0) == 0xC0) {
                buffer.get(); // Skip the pointer byte
                break;
            }
            buffer.position(buffer.position() + length);
        }
    }

    private String parseName(ByteBuffer buffer) {
        StringBuilder name = new StringBuilder();
        while (true) {
            int length = buffer.get() & 0xFF;
            if (length == 0) break;
            if ((length & 0xC0) == 0xC0) { // Pointer to another part of the message
                int pointer = ((length & 0x3F) << 8) | (buffer.get() & 0xFF);
                int currentPos = buffer.position();
                buffer.position(pointer);
                name.append(parseName(buffer));
                buffer.position(currentPos);
                break;
            } else {
                byte[] label = new byte[length];
                buffer.get(label);
                name.append(new String(label, StandardCharsets.UTF_8)).append(".");
            }
        }
        return name.toString();
    }

    public static void main(String[] args) throws Exception {
        StubResolver resolver = new StubResolver();
        resolver.setNameServer(InetAddress.getByAddress(new byte[]{1, 1, 1, 1}), 53);

    }
}*/


import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

public class StubResolver {

    private InetAddress dnsServer;
    private int port;
    private DatagramSocket socket;

    public StubResolver() throws Exception {
        this.socket = new DatagramSocket();
    }

    public void setNameServer(InetAddress dnsServer, int port) {
        this.dnsServer = dnsServer;
        this.port = port;
    }

    public InetAddress recursiveResolveAddress(String domain) throws Exception {
        byte[] response = sendQuery(domain, 1); // A record type
        return parseAddressResponse(response);
    }

    public String recursiveResolveText(String domain) throws Exception {
        byte[] response = sendQuery(domain, 16); // TXT record type
        return parseTextResponse(response);
    }

    public String recursiveResolveName(String domain, int queryType) throws Exception {
        byte[] response = sendQuery(domain, queryType); // CNAME record type
        return parseCNAMEResponse(response);
    }

    public String recursiveResolveNS(String domain) throws Exception {
        byte[] response = sendQuery(domain, 2); // NS record type
        return parseNSResponse(response);
    }

    public String recursiveResolveMX(String domain) throws Exception {
        byte[] response = sendQuery(domain, 15); // MX record type
        return parseMXResponse(response);
    }

    private byte[] sendQuery(String domain, int queryType) throws Exception {
        byte[] query = buildQuery(domain, queryType);
        DatagramPacket packet = new DatagramPacket(query, query.length, dnsServer, port);
        socket.send(packet);

        byte[] responseBuffer = new byte[512];
        DatagramPacket responsePacket = new DatagramPacket(responseBuffer, responseBuffer.length);
        socket.receive(responsePacket);

        return responsePacket.getData();
    }

    private byte[] buildQuery(String domain, int queryType) throws Exception {
        ByteBuffer buffer = ByteBuffer.allocate(512);

        // Transaction ID
        buffer.putShort((short) 0x1234);
        // Flags
        buffer.putShort((short) 0x0100);
        // Questions
        buffer.putShort((short) 1);
        // Answer RRs
        buffer.putShort((short) 0);
        // Authority RRs
        buffer.putShort((short) 0);
        // Additional RRs
        buffer.putShort((short) 0);

        String[] labels = domain.split("\\.");
        for (String label : labels) {
            buffer.put((byte) label.length());
            buffer.put(label.getBytes(StandardCharsets.UTF_8));
        }
        buffer.put((byte) 0); // End of domain name

        buffer.putShort((short) queryType); // Query Type
        buffer.putShort((short) 1); // Class IN

        byte[] query = new byte[buffer.position()];
        buffer.flip();
        buffer.get(query);

        return query;
    }

    private InetAddress parseAddressResponse(byte[] response) throws Exception {
        ByteBuffer buffer = ByteBuffer.wrap(response);

        buffer.getShort(); // Transaction ID
        buffer.getShort(); // Flags
        buffer.getShort(); // Questions
        short answerCount = buffer.getShort(); // Answer RRs
        buffer.getShort(); // Authority RRs
        buffer.getShort(); // Additional RRs

        // Skip the query section
        skipName(buffer);
        buffer.getShort(); // Query Type
        buffer.getShort(); // Query Class

        if (answerCount > 0) {
            // Parse answer section
            skipName(buffer);
            short type = buffer.getShort();
            buffer.getShort(); // Class
            buffer.getInt(); // TTL
            short dataLength = buffer.getShort(); // Data length

            if (type == 1 && dataLength == 4) { // A Record
                byte[] data = new byte[dataLength];
                buffer.get(data);
                return InetAddress.getByAddress(data);
            }
        }

        return null;
    }

    private String parseTextResponse(byte[] response) throws Exception {
        ByteBuffer buffer = ByteBuffer.wrap(response);

        buffer.getShort(); // Transaction ID
        buffer.getShort(); // Flags
        buffer.getShort(); // Questions
        short answerCount = buffer.getShort(); // Answer RRs
        buffer.getShort(); // Authority RRs
        buffer.getShort(); // Additional RRs

        // Skip the query section
        skipName(buffer);
        buffer.getShort(); // Query Type
        buffer.getShort(); // Query Class

        if (answerCount > 0) {
            // Parse answer section
            skipName(buffer);
            short type = buffer.getShort();
            buffer.getShort(); // Class
            buffer.getInt(); // TTL
            short dataLength = buffer.getShort(); // Data length

            if (type == 16) { // TXT Record
                int txtLength = buffer.get() & 0xFF;
                byte[] data = new byte[txtLength];
                buffer.get(data);
                return new String(data, StandardCharsets.UTF_8);
            }
        }

        return null;
    }

    private String parseCNAMEResponse(byte[] response) throws Exception {
        ByteBuffer buffer = ByteBuffer.wrap(response);

        buffer.getShort(); // Transaction ID
        buffer.getShort(); // Flags
        buffer.getShort(); // Questions
        short answerCount = buffer.getShort(); // Answer RRs
        buffer.getShort(); // Authority RRs
        buffer.getShort(); // Additional RRs

        // Skip the query section
        skipName(buffer);
        buffer.getShort(); // Query Type
        buffer.getShort(); // Query Class

        if (answerCount > 0) {
            // Parse answer section
            return parseName(buffer);
        }

        return null;
    }

    private String parseNSResponse(byte[] response) throws Exception {
        ByteBuffer buffer = ByteBuffer.wrap(response);

        buffer.getShort(); // Transaction ID
        buffer.getShort(); // Flags
        buffer.getShort(); // Questions
        short answerCount = buffer.getShort(); // Answer RRs
        buffer.getShort(); // Authority RRs
        buffer.getShort(); // Additional RRs

        // Skip the query section
        skipName(buffer);
        buffer.getShort(); // Query Type
        buffer.getShort(); // Query Class

        if (answerCount > 0) {
            // Parse answer section
            skipName(buffer); // Skip the name
            short type = buffer.getShort();
            buffer.getShort(); // Class
            buffer.getInt(); // TTL
            short dataLength = buffer.getShort(); // Data length

            if (type == 2) { // NS Record
                return parseName(buffer);
            }
        }

        return null;
    }

    private String parseMXResponse(byte[] response) throws Exception {
        ByteBuffer buffer = ByteBuffer.wrap(response);

        buffer.getShort(); // Transaction ID
        buffer.getShort(); // Flags
        buffer.getShort(); // Questions
        short answerCount = buffer.getShort(); // Answer RRs
        buffer.getShort(); // Authority RRs
        buffer.getShort(); // Additional RRs

        // Skip the query section
        skipName(buffer);
        buffer.getShort(); // Query Type
        buffer.getShort(); // Query Class

        if (answerCount > 0) {
            // Parse answer section
            skipName(buffer); // Skip the name
            short type = buffer.getShort();
            buffer.getShort(); // Class
            buffer.getInt(); // TTL
            short dataLength = buffer.getShort(); // Data length

            if (type == 15) { // MX Record
                short preference = buffer.getShort(); // Preference
                String exchange = parseName(buffer); // Exchange
                return preference + " " + exchange;
            }
        }

        return null;
    }

    private void skipName(ByteBuffer buffer) {
        while (true) {
            int length = buffer.get() & 0xFF;
            if (length == 0) break;
            if ((length & 0xC0) == 0xC0) {
                buffer.get(); // Skip the pointer byte
                break;
            }
            buffer.position(buffer.position() + length);
        }
    }

    private String parseName(ByteBuffer buffer) {
        StringBuilder name = new StringBuilder();
        while (true) {
            int length = buffer.get() & 0xFF;
            if (length == 0) break;
            if ((length & 0xC0) == 0xC0) { // Pointer to another part of the message
                int pointer = ((length & 0x3F) << 8) | (buffer.get() & 0xFF);
                int currentPos = buffer.position();
                buffer.position(pointer);
                name.append(parseName(buffer));
                buffer.position(currentPos);
                break;
            } else {
                byte[] label = new byte[length];
                buffer.get(label);
                name.append(new String(label, StandardCharsets.UTF_8)).append(".");
            }
        }
        return name.toString();
    }

    public static void main(String[] args) throws Exception {
        StubResolver resolver = new StubResolver();
        resolver.setNameServer(InetAddress.getByAddress(new byte[]{1, 1, 1, 1}), 53);

    }
}

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

class DNSParsingException extends Exception {
    public DNSParsingException(String message) {
        super(message);
    }
}

class DNSRecord {
    String domainName;
    int recordType;
    int recordClass;
    int ttl;
    String data;

    public DNSRecord(String domainName, int recordType, int recordClass, int ttl, String data) {
        this.domainName = domainName;
        this.recordType = recordType;
        this.recordClass = recordClass;
        this.ttl = ttl;
        this.data = data;
    }

    @Override
    public String toString() {
        return String.format("Domain: %s, Type: %d, Class: %d, TTL: %d, Data: %s",
                domainName, recordType, recordClass, ttl, data);
    }
}

public class DNSParser {

    public static void main(String[] args) {
        try {
            // Example DNS response in raw byte format
            byte[] dnsResponse = {/* DNS Response bytes here */};

            List<DNSRecord> records = parseDNSRecords(ByteBuffer.wrap(dnsResponse));

            for (DNSRecord record : records) {
                System.out.println(record);
            }
        } catch (DNSParsingException e) {
            e.printStackTrace();
        }
    }

    public static List<DNSRecord> parseDNSRecords(ByteBuffer buffer) throws DNSParsingException {
        List<DNSRecord> records = new ArrayList<>();

        try {
            while (buffer.hasRemaining()) {
                String domainName = parseDomainName(buffer);
                int recordType = buffer.getShort() & 0xFFFF;
                int recordClass = buffer.getShort() & 0xFFFF;
                int ttl = buffer.getInt();
                int dataLength = buffer.getShort() & 0xFFFF;

                if (buffer.remaining() < dataLength) {
                    throw new DNSParsingException("Not enough data for expected record length");
                }

                byte[] data = new byte[dataLength];
                buffer.get(data);

                String recordData = parseRecordData(recordType, data);
                if (recordData == null) {
                    System.err.println("Parsed record data is null, check handling of record type: " + recordType);
                    continue;  // Skip adding this record
                }

                DNSRecord record = new DNSRecord(domainName, recordType, recordClass, ttl, recordData);
                records.add(record);
            }
        } catch (Exception e) {
            throw new DNSParsingException("Error parsing DNS records: " + e.getMessage());
        }

        return records;
    }

    private static String parseDomainName(ByteBuffer buffer) throws DNSParsingException {
        StringBuilder domainName = new StringBuilder();
        int length = buffer.get() & 0xFF;

        while (length != 0) {
            if ((length & 0xC0) == 0xC0) { // Pointer to a previous domain name
                int pointer = ((length & 0x3F) << 8) | (buffer.get() & 0xFF);
                int currentPos = buffer.position();
                buffer.position(pointer);
                domainName.append(parseDomainName(buffer));
                buffer.position(currentPos);
                return domainName.toString();
            } else { // Regular label
                byte[] label = new byte[length];
                buffer.get(label);
                domainName.append(new String(label)).append(".");
                length = buffer.get() & 0xFF;
            }
        }

        if (domainName.length() > 0) {
            domainName.setLength(domainName.length() - 1);
        }

        return domainName.toString();
    }

    private static String parseRecordData(int recordType, byte[] data) {
        switch (recordType) {
            case 1: // A record
                if (data.length == 4) {
                    return String.format("%d.%d.%d.%d", data[0] & 0xFF, data[1] & 0xFF, data[2] & 0xFF, data[3] & 0xFF);
                } else {
                    System.err.println("Invalid data length for A record: " + data.length);
                    return null;
                }
            case 28: // AAAA record
                if (data.length == 16) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < data.length; i += 2) {
                        sb.append(String.format("%02x", data[i] & 0xFF));
                        sb.append(String.format("%02x", data[i + 1] & 0xFF));
                        if (i < data.length - 2) sb.append(":");
                    }
                    return sb.toString();
                } else {
                    System.err.println("Invalid data length for AAAA record: " + data.length);
                    return null;
                }
            case 2: // NS record
                // NS data should be a domain name
                return new String(data);  // Simplified: real parsing should handle compression if needed
            default:
                System.err.println("Unsupported record type: " + recordType);
                return null;
        }
    }
}

// IN2011 Computer Networks
// Coursework 2023/2024 Resit
//
// Submission by
// YOUR_NAME_GOES_HERE
// YOUR_STUDENT_ID_NUMBER_GOES_HERE
// YOUR_EMAIL_GOES_HERE


import java.net.*;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.util.*;

interface ResolverInterface {
    void setNameServer(InetAddress ipAddress, int port);
    InetAddress iterativeResolveAddress(String domainName) throws Exception;
    String iterativeResolveText(String domainName) throws Exception;
    String iterativeResolveName(String domainName, int type) throws Exception;
}

public class Resolver implements ResolverInterface {

    private InetAddress nameServer;
    private int port;

    @Override
    public void setNameServer(InetAddress ipAddress, int port) {
        this.nameServer = ipAddress;
        this.port = port;
    }

    private byte[] buildQuery(String domainName, int qtype) {
        ByteBuffer buffer = ByteBuffer.allocate(512);
        short transactionID = (short) new Random().nextInt(Short.MAX_VALUE + 1);
        buffer.putShort(transactionID);

        buffer.putShort((short) 0x0100); // Flags (standard query, recursion desired)
        buffer.putShort((short) 1); // QDCOUNT (number of questions)
        buffer.putShort((short) 0); // ANCOUNT
        buffer.putShort((short) 0); // NSCOUNT
        buffer.putShort((short) 0); // ARCOUNT

        for (String part : domainName.split("\\.")) {
            buffer.put((byte) part.length());
            buffer.put(part.getBytes());
        }
        buffer.put((byte) 0); // End of QNAME

        buffer.putShort((short) qtype);
        buffer.putShort((short) 1); // QCLASS (IN - Internet)

        return Arrays.copyOfRange(buffer.array(), 0, buffer.position());
    }

    private String[] decodeLabels(ByteBuffer buffer) throws Exception {
        StringBuilder result = new StringBuilder();

        while (buffer.hasRemaining()) {
            int len = buffer.get() & 0xFF;
            if (len == 0) break; // End of the name

            if ((len & 0xC0) == 0xC0) { // Pointer encountered
                int pointer = ((len & 0x3F) << 8) | (buffer.get() & 0xFF);
                ByteBuffer pointerBuffer = buffer.duplicate();
                pointerBuffer.position(pointer);
                result.append(String.join(".", decodeLabels(pointerBuffer)));
                break;
            } else {
                byte[] label = new byte[len];
                buffer.get(label);
                result.append(new String(label)).append('.');
            }
        }

        return result.toString().split("\\.");
    }

    private String parseResourceRecord(ByteBuffer buffer, int recordType, int rdlength) throws Exception {
        if (buffer.remaining() < rdlength) {
            throw new BufferUnderflowException();
        }

        switch (recordType) {
            case 1: // A record
                if (rdlength != 4) throw new BufferUnderflowException(); // A record length must be 4 bytes
                byte[] ipBytes = new byte[4];
                buffer.get(ipBytes);
                InetAddress ip = InetAddress.getByAddress(ipBytes);
                return ip.getHostAddress();

            case 28: // AAAA record
                if (rdlength != 16) throw new BufferUnderflowException(); // AAAA record length must be 16 bytes
                byte[] ipv6Bytes = new byte[16];
                buffer.get(ipv6Bytes);
                InetAddress ipv6 = InetAddress.getByAddress(ipv6Bytes);
                return ipv6.getHostAddress();

            case 2: // NS record
            case 5: // CNAME
                return String.join(".", decodeLabels(buffer));

            case 16: // TXT record
                StringBuilder txtResult = new StringBuilder();
                while (buffer.remaining() > 0) {
                    int txtLen = buffer.get() & 0xFF;
                    byte[] txtBytes = new byte[txtLen];
                    buffer.get(txtBytes);
                    txtResult.append(new String(txtBytes));
                }
                return txtResult.toString();

            default:
                buffer.position(buffer.position() + rdlength); // Skip unknown record types
                return null;
        }
    }

    private List<String> parseResponse(byte[] response, String domainName, int qtype, List<String> nsRecords, Map<String, String> glueRecords) throws Exception {
        ByteBuffer buffer = ByteBuffer.wrap(response);

        try {
            buffer.getShort(); // Transaction ID
            buffer.getShort(); // Flags
            buffer.getShort(); // QDCOUNT

            int ancount = buffer.getShort() & 0xFFFF;
            int nscount = buffer.getShort() & 0xFFFF;
            int arcount = buffer.getShort() & 0xFFFF;

            // Skip question section
            decodeLabels(buffer); // QNAME
            buffer.getShort(); // QTYPE
            buffer.getShort(); // QCLASS

            List<String> results = new ArrayList<>();

            for (int i = 0; i < ancount; i++) {
                if (!buffer.hasRemaining()) break;

                decodeLabels(buffer); // NAME
                int recordType = buffer.getShort() & 0xFFFF;
                buffer.getShort(); // CLASS
                buffer.getInt(); // TTL
                int rdlength = buffer.getShort() & 0xFFFF;

                if (rdlength > buffer.remaining() || !isValidRecordType(recordType)) {
                    if (buffer.remaining() >= rdlength) {
                        buffer.position(buffer.position() + rdlength);
                    } else {
                        break;
                    }
                    continue;
                }

                String result = parseResourceRecord(buffer, recordType, rdlength);
                if (result != null) {
                    if (recordType == qtype) {
                        results.add(result);
                    } else if (recordType == 5) { // CNAME
                        return Arrays.asList(result); // Return CNAME to resolve it further
                    }
                }
            }

            for (int i = 0; i < nscount; i++) {
                if (!buffer.hasRemaining()) break;

                String nsName = String.join(".", decodeLabels(buffer)); // NAME
                int recordType = buffer.getShort() & 0xFFFF;
                buffer.getShort(); // CLASS
                buffer.getInt(); // TTL
                int rdlength = buffer.getShort() & 0xFFFF;

                if (rdlength > buffer.remaining() || !isValidRecordType(recordType)) {
                    if (buffer.remaining() >= rdlength) {
                        buffer.position(buffer.position() + rdlength);
                    } else {
                        break;
                    }
                    continue;
                }

                String nsRecord = parseResourceRecord(buffer, recordType, rdlength);
                if (nsRecord != null && recordType == 2) { // NS record type
                    nsRecords.add(nsRecord);
                }
            }

            // Handle additional records (e.g., glue A/AAAA records)
            for (int i = 0; i < arcount; i++) {
                if (!buffer.hasRemaining()) break;

                String name = String.join(".", decodeLabels(buffer)); // NAME
                int recordType = buffer.getShort() & 0xFFFF;
                buffer.getShort(); // CLASS
                buffer.getInt(); // TTL
                int rdlength = buffer.getShort() & 0xFFFF;

                if (rdlength > buffer.remaining() || !isValidRecordType(recordType)) {
                    if (buffer.remaining() >= rdlength) {
                        buffer.position(buffer.position() + rdlength);
                    } else {
                        break;
                    }
                    continue;
                }

                if (recordType == 1 || recordType == 28) { // A or AAAA record type
                    String aaaaRecord = parseResourceRecord(buffer, recordType, rdlength);
                    if (aaaaRecord != null) {
                        glueRecords.put(name, aaaaRecord); // Store glue records in the map
                    }
                }
            }

            return results;
        } catch (BufferUnderflowException e) {
            throw e;
        }
    }

    private InetAddress findIPForNS(List<String> nsRecords, Map<String, String> glueRecords) throws Exception {
        for (String nsName : nsRecords) {

            // Check if we already have a glue record for this NS
            if (glueRecords.containsKey(nsName)) {
                InetAddress ip = InetAddress.getByName(glueRecords.get(nsName));
                return ip;
            }

            // Attempt to resolve NS if no glue record
            InetAddress ip = iterativeResolveAddress(nsName);
            if (ip != null) {
                return ip;
            }
        }
        return null;
    }

    private boolean isValidRecordType(int recordType) {
        // Define the set of valid DNS record types your resolver will handle
        return recordType == 1   // A record
                || recordType == 2   // NS record
                || recordType == 5   // CNAME record
                || recordType == 6   // SOA record
                || recordType == 12  // PTR record
                || recordType == 15  // MX record
                || recordType == 16  // TXT record
                || recordType == 28; // AAAA record
    }

    private String iterativeQuery(String domainName, int qtype) throws Exception {
        InetAddress currentServer = nameServer;
        Set<String> visitedCNAMEs = new HashSet<>();  // Track visited CNAMEs to avoid loops
        Map<String, String> glueRecords = new HashMap<>();  // Store glue records

        for (int i = 0; i < 10; i++) {  // Limit the number of hops to avoid infinite loops
            DatagramSocket socket = new DatagramSocket();
            socket.setSoTimeout(5000);

            byte[] query = buildQuery(domainName, qtype);
            DatagramPacket packet = new DatagramPacket(query, query.length, currentServer, port);

            try {
                socket.send(packet);
                byte[] responseBuffer = new byte[512];
                DatagramPacket responsePacket = new DatagramPacket(responseBuffer, responseBuffer.length);
                socket.receive(responsePacket);

                List<String> nsRecords = new ArrayList<>();
                List<String> results = parseResponse(responsePacket.getData(), domainName, qtype, nsRecords, glueRecords);

                if (!results.isEmpty()) {
                    String firstResult = results.get(0);

                    // Handle CNAME resolution
                    if (qtype == 5) { // CNAME query
                        if (visitedCNAMEs.contains(firstResult)) {
                            throw new Exception("CNAME loop detected for domain: " + firstResult);
                        }
                        visitedCNAMEs.add(firstResult);
                        return firstResult; // Return the CNAME target
                    }

                    // If we queried for an A/AAAA record but found a CNAME, continue resolving
                    if (qtype == 1 && visitedCNAMEs.contains(domainName)) {
                        return iterativeQuery(firstResult, qtype); // Continue resolving the CNAME
                    }

                    return firstResult;  // Return the resolved record
                }

                // If no direct results, check NS records
                if (!nsRecords.isEmpty()) {
                    InetAddress nextServerIP = findIPForNS(nsRecords, glueRecords);
                    if (nextServerIP != null) {
                        currentServer = nextServerIP;
                    } else {
                        break; // Stop if no NS can be resolved
                    }
                } else {
                    break; // Stop if no NS records are found
                }
            } catch (SocketTimeoutException e) {
                continue; // Retry the query on timeout
            } finally {
                socket.close();
            }
        }

        throw new Exception("Failed to resolve domain after multiple hops.");
    }

    @Override
    public InetAddress iterativeResolveAddress(String domainName) throws Exception {
        String result = iterativeQuery(domainName, 1); // A record type
        if (result != null) {
            return InetAddress.getByName(result);
        }
        return null;
    }

    @Override
    public String iterativeResolveText(String domainName) throws Exception {
        return iterativeQuery(domainName, 16); // TXT record type
    }

    @Override
    public String iterativeResolveName(String domainName, int type) throws Exception {
        return iterativeQuery(domainName, type); // CNAME or other records
    }
}
